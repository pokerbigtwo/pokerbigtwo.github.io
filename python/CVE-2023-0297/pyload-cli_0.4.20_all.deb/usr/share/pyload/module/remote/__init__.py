# -*- coding: utf-8 -*-
activated = True
